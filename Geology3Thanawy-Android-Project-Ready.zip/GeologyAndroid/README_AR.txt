تطبيق جيولوجيا 3 ثانوي - مشروع Android Studio

المشروع يفتح بنك الأسئلة المرفق محلياً داخل WebView، ولا يحتاج إلى اتصال إنترنت أثناء الاستخدام.

طريقة إخراج APK:
1) فك ضغط Geology3Thanawy-Android-Project.zip على كمبيوتر.
2) افتح Android Studio واختر Open ثم اختر مجلد GeologyAndroid.
3) انتظر انتهاء Gradle Sync وتنزيل مكونات Android المطلوبة.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ستجد الملف غالباً في:
   app/build/outputs/apk/debug/app-debug.apk
6) انقل APK إلى هاتف Android وثبّته. قد يطلب الهاتف السماح بالتثبيت من هذا المصدر.

المتطلبات:
- Android Studio حديث.
- JDK 17 أو أحدث.
- Android SDK Platform 35.
- اتصال إنترنت أول مرة لتنزيل Gradle ومكونات Android.

ملاحظة:
هذا مشروع مصدر جاهز للبناء وليس ملف APK مجمّعاً. لم يتم إنشاء أو اختبار APK داخل بيئة المحادثة.
